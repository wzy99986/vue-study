<template>
  <div class='watch-new-music'></div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class WatchNewMusic extends Vue{
  
created(){}
 
}
</script>
<style scoped lang='less'>
.watch-new-music{}
</style>