<template>
  <div class='my-radio'></div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class MyRadio extends Vue{
  
created(){}
 
}
</script>
<style scoped lang='less'>
.my-radio{}
</style>