<template>
  <div class='my-star'></div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class MyStar extends Vue{
  
created(){}
 
}
</script>
<style scoped lang='less'>
.my-star{}
</style>