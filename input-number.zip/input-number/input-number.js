const inputComponents = Vue.extend({
    template: `
        <div>
            <button @click="increment">+</button><input type="number" style="width:50px;" :value="cnumber" @input="handlerChange($event)" /><button @click="decrement">-</button>
        </div>
    `,
    props: {
        cnumber: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            currentValue: this.cnumber
        }
    },
    methods: {
        increment() {
            this.currentValue++;
        },
        decrement() {
            this.currentValue--;
        },
        handlerChange(event) {
            this.currentValue = parseInt(event.target.value)
        }
    },
    watch: {
        currentValue: {
            handler(newValue, oldValue) {
                this.$emit('change', this.currentValue)
            },
            deep: true
        }
    },
})