const vm = new Vue({
    el: '#app',
    data: {
        number: 0
    },
    components: {
        inputComponents
    },
    methods: {
        numChange(val) {
            this.number = val
        }
    }
})